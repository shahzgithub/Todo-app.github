const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

// Middleware to parse JSON bodies

app.use(bodyParser.json());

let users = [];

// GET /api/users - Get all users

app.get('/api/users', (req, res) => {
    res.json(users);
});

// POST /api/users - Create a new user

app.post('/api/users', (req, res) => {
    const newUser = req.body;
    users.push(newUser);
    res.status(201).json(newUser);
});

// PUT /api/users/:id - Update a user by ID

app.put('/api/users/:id', (req, res) => {
    const userId = req.params.id;
    const updatedUser = req.body;
    users = users.map(user => {
        if (user.id === userId) {
            return { ...user, ...updatedUser };
        }
        return user;
    });
    res.json(updatedUser);
});

// DELETE /api/users/:id - Delete a user by ID

app.delete('/api/users/:id', (req, res) => {
    const userId = req.params.id;
    users = users.filter(user => user.id !== userId);
    res.sendStatus(204);
});

// Start the server

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
